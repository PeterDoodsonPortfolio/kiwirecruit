from django.apps import AppConfig


class UserprofilesConfig(AppConfig):
    name = 'userprofiles'
